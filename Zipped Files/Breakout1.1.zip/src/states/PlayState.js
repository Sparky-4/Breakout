class PlayState{
	
	constructor()
	{
		this.paused = false;
		this.cooldown = 10;
		this.isHit = false;
		this.oneUp = 500;
		this.isOneUp = false;
		this.color = "#67ffff";
	}
	
	enter(params)
	{
		this.paddle = params.paddle;
		this.bricks = params.bricks;
		this.health = params.health;
		this.score = params.score;
		this.ball = params.ball;
		this.level = params.level;
		this.cooldown = 10;
		currentBallSpeed = BALL_SPEED;
	}
	
	checkVictory()
	{
		for(let i = 0; i < this.bricks.length; i++)
			if(this.bricks[i].inPlay)
				return false;
		return true;
	}
	
	update()
	{
		if(keys && keys[82])
			location.reload();
		if (this.paused)
		{
			if(keys && keys[32] && this.cooldown <= 0)
			{
				this.paused = false;
				gSounds.pause.play();
				this.cooldown = 10;
			}
			else
			{
				this.cooldown--;
				return;
			}
				
		}
		else if(keys && keys[32] && this.cooldown <= 0)
		{
			this.paused = true;
			gSounds.pause.play();
			this.cooldown = 10;
			return;
		}
		
		this.cooldown--;
		this.paddle.update();
		this.ball.update();
		
		if(this.ball.collides(this.paddle) && this.ball.dy > 0)
		{
			this.ball.dy *= -1;
			
			if(this.ball.x < this.paddle.x && this.ball.dx > 0 && this.paddle.dx == 0)
				this.ball.dx *= -1;
			else if(this.ball.x + this.ball.width > this.paddle.x + this.paddle.width && this.ball.dx < 0 && this.paddle.dx == 0)
				this.ball.dx *= -1;
			else if(this.ball.x + this.ball.width < this.paddle.x + (this.paddle.width/2) && this.paddle.dx < 0)
				this.ball.dx = -BALL_SPEED * ((this.paddle.x + this.paddle.width/2 - (this.ball.x + this.ball.width))/(this.paddle.width/2));
			
			else if(this.ball.x + this.ball.width > this.paddle.x + (this.paddle.width/2) && this.paddle.dx > 0)
				this.ball.dx = -BALL_SPEED * ((this.paddle.x + this.paddle.width/2 - this.ball.x)/(this.paddle.width/2));
			currentBallSpeed *= 1.02;
			this.ball.setSpeed(this.ball.dx, this.ball.dy);
			gSounds.paddle_hit.play();
		}
		
		for(let i = 0; i < this.bricks.length; i++)
		{
			if(!this.isHit)
			{	
				if(this.bricks[i].inPlay && this.ball.collides(this.bricks[i]))
				{ 
					this.score += ((this.bricks[i].color + 1) * 10) + (this.bricks[i].tier * 25);
					this.bricks[i].hit();
					
					this.isHit = true;
					if(this.ball.x + 2*SCALE_FACTOR_WIDTH < this.bricks[i].x && this.ball.dx > 0)
					{
						this.ball.dx = -this.ball.dx;
						this.ball.x = this.bricks[i].x - this.ball.width;
						console.log('left')
					}
					else if(this.ball.x + 6*SCALE_FACTOR_WIDTH > this.bricks[i].x + this.bricks[i].width && this.ball.dx < 0)
					{
						this.ball.dx = -this.ball.dx;
						this.ball.x = this.bricks[i].x + this.bricks[i].width;
						console.log('right')
					}
					else if(this.ball.y < this.bricks[i].y)
					{
						this.ball.dy = -this.ball.dy;
						this.ball.y = this.bricks[i].y - this.ball.height;
						console.log('top')
					}
					else 
					{
						this.ball.dy = -this.ball.dy;
						this.ball.y = this.bricks[i].y + this.bricks[i].height;
						console.log('bottom')
					}
					
				}
			}
		}
		this.isHit = false;
		
		if(this.score >= this.oneUp)
		{
			this.oneUp *= 2;
			this.isOneUp = true;
			this.health++;
			gSounds.recover.load();
			gSounds.recover.play();
			
			setTimeout(function(){gStateMachine.current.isOneUp = false; }, 1000);
			for(let i = 0; i < 10; i++)
				setTimeout(function(){
					gStateMachine.current.color == 'white' ? gStateMachine.current.color = '#67ffff' : gStateMachine.current.color = 'white'; 
				}, i*100);
		}
		
		if(this.checkVictory())
		{
			gSounds.victory.load();
			gSounds.victory.play();
			
			gStateMachine.change('victory', {
					paddle: this.paddle,
					health: this.health,
					score: this.score,
					ball: this.ball,
					level: this.level,
			});
		}
		
		
		if(this.ball.y >= WINDOW_HEIGHT)
		{
			this.health--;
			gSounds.hurt.play();
			if(this.health == 0)
			{
				gSounds.music.pause();
				for(let i = 0; i < 10; i++)
				{
					console.log(highScores[i], this.score)
					if(highScores[i] < this.score)
					{
						gSounds.high_score.load();
						gSounds.high_score.play();
						gStateMachine.change('enter', this.score);
						return;
					}
						
				}
				gStateMachine.change('game_over', {
					score: this.score
				});
			}
				
			else
				gStateMachine.change('serve', {
					paddle: this.paddle,
					bricks: this.bricks,
					health: this.health,
					score: this.score,
					level: this.level,
				});
		}
		
		if(keys && keys[27])
			window.close();
		

	}
	
	render()
	{
		for(let i = 0; i < this.bricks.length; i++)
			this.bricks[i].render();
		for(let i = 0; i < this.bricks.length; i++)
			this.bricks[i].pSystem.updateParticles();
		this.paddle.render();
		this.ball.render();
		renderScore(this.score);
		renderHealth(this.health);
		if(this.paused)
		{
			ctx.font = gFonts.large;
			ctx.fillStyle = 'green';
			ctx.textAlign = 'center';
			ctx.fillText("PAUSED", VIRTUAL_WIDTH*SCALE_FACTOR_WIDTH / 2,VIRTUAL_HEIGHT*SCALE_FACTOR_HEIGHT / 2);
		}
		
		if(this.isOneUp)
		{
			ctx.font = gFonts.large;
			ctx.fillStyle = 'white';
			ctx.textAlign = 'center';
			ctx.fillStyle = this.color;
			ctx.fillText("Life Increased!", WINDOW_WIDTH / 2, WINDOW_HEIGHT / 2);
			gFrames.powerUps[2].draw(WINDOW_WIDTH / 2 - 10*SCALE_FACTOR_WIDTH, WINDOW_HEIGHT *2/3 - 10*SCALE_FACTOR_HEIGHT, 20, 20);
		}
	}
}