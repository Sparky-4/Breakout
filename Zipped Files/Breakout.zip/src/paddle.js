class Paddle{
	
	constructor(skin)
	{
		this.x = VIRTUAL_WIDTH*SCALE_FACTOR_WIDTH / 2 - 32*SCALE_FACTOR_WIDTH;
		this.y = VIRTUAL_HEIGHT*SCALE_FACTOR_HEIGHT - 32*SCALE_FACTOR_HEIGHT;
		this.dx = 0;
		this.width = 64*SCALE_FACTOR_WIDTH;
		this.height = 16*SCALE_FACTOR_HEIGHT;
		this.skin = skin;
		this.size = 1;
		
	}
	
	update()
	{
		if(keys && keys[37])
			this.dx = -PADDLE_SPEED;
		else if (keys && keys[39])
			this.dx = PADDLE_SPEED;
		else 
			this.dx = 0;
		
		this.x += this.dx;
		if(this.x <= 0)
			this.x = 0;
		else if(this.x >= VIRTUAL_WIDTH*SCALE_FACTOR_WIDTH - this.width)
			this.x = VIRTUAL_WIDTH*SCALE_FACTOR_WIDTH - this.width;
		
	}
	
	render()
	{
		gFrames.paddles[this.size + 4*(this.skin)].draw(this.x, this.y);
	}
}